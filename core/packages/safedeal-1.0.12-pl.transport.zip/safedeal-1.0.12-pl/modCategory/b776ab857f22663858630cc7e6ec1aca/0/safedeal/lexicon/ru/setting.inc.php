<?php

$_lang['area_safedeal_main'] = 'Основные';
$_lang['area_safedeal_payments'] = 'Платежи';

$_lang['setting_safedeal_merchant_apikey'] = 'АПИ токен';
$_lang['setting_safedeal_merchant_apikey_desc'] = 'Токен выдается эквайрингом';
$_lang['setting_safedeal_merchant_currency'] = 'Валюта платежа';
$_lang['setting_safedeal_merchant_currency_desc'] = 'По умолчанию RUB';
$_lang['setting_safedeal_merchant_id'] = 'ID мерчанта';
$_lang['setting_safedeal_merchant_id_desc'] = 'ID выдается эквайрингом';
$_lang['setting_safedeal_merchant_ttl'] = 'Время жизни счета';
$_lang['setting_safedeal_merchant_ttl_desc'] = 'Время действия счета (в часах) от момента создания. По истечении этого времени оплата невозможна (счет будет отменен)';
$_lang['setting_safedeal_merchant_host'] = 'HOST АПИ запросов';
$_lang['setting_safedeal_merchant_host_desc'] = 'HOST выдается эквайрингом';
$_lang['setting_safedeal_merchant_invoice_url'] = 'URL АПИ запросов';
$_lang['setting_safedeal_merchant_invoice_url_desc'] = 'URL выдается эквайрингом';
$_lang['setting_safedeal_merchant_payform_url'] = 'URL передачи данных карты запросов';
$_lang['setting_safedeal_merchant_payform_url_desc'] = 'URL выдается эквайрингом';
$_lang['setting_safedeal_merchant_result_url'] = 'URL для callback запросов от эквайринга';
$_lang['setting_safedeal_merchant_result_url_desc'] = 'На этот URL эквайринг будет отправлять результаты отплаты';