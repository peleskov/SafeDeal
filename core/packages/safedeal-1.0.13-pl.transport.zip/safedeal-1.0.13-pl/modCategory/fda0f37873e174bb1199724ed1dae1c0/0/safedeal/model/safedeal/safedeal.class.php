<?php
class SafeDeal extends xPDOSimpleObject {}