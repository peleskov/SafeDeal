<?php
require_once (dirname(__DIR__) . '/dealnotice.class.php');
class DealNotice_mysql extends DealNotice {}