<?php
require_once (dirname(__DIR__) . '/deal.class.php');
class Deal_mysql extends Deal {}