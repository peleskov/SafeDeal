--------------------
SafeDeal
--------------------
Authors:
    Sergei Peleskov <info@s1temaker.ru>
--------------------

Safe Deal for MODx Revolution.