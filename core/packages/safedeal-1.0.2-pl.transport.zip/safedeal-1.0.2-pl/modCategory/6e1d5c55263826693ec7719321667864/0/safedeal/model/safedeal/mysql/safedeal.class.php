<?php
require_once (dirname(__DIR__) . '/safedeal.class.php');
class SafeDeal_mysql extends SafeDeal {}