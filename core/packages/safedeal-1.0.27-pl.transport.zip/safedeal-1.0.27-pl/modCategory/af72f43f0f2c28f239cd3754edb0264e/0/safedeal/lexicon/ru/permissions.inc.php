<?php
/**
 * English permissions Lexicon Entries for SafeDeal
 *
 * @package SafeDeal
 * @subpackage lexicon
 */
$_lang['safedeal_save'] = 'Разрешает создание/изменение данных.';