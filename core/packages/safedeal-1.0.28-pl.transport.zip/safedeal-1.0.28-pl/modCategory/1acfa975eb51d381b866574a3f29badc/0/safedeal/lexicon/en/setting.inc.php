<?php

$_lang['area_safedeal_main'] = 'Main';
$_lang['area_safedeal_payments'] = 'Payments';

$_lang['setting_safedeal_some_setting'] = 'Some setting';
$_lang['setting_safedeal_some_setting_desc'] = 'This is description for some setting';