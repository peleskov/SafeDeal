<?php
/**
 * Russian permissions Lexicon Entries for SafeDeal
 *
 * @package SafeDeal
 * @subpackage lexicon
 */
$_lang['safedeal_save'] = 'Permission for save/update data.';