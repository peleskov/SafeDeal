<?php

$_lang['area_safedeal_main'] = 'Основные';

$_lang['setting_safedeal_some_setting'] = 'Какая-то настройка';
$_lang['setting_safedeal_some_setting_desc'] = 'Это описание для какой-то настройки';