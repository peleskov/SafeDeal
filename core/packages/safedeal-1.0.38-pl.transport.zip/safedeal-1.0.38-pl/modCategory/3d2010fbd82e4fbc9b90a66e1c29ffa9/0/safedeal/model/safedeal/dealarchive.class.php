<?php
class DealArchive extends xPDOSimpleObject {}