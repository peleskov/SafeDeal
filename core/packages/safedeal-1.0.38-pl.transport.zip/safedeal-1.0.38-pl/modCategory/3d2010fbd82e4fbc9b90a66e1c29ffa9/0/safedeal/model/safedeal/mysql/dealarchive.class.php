<?php
require_once (dirname(__DIR__) . '/dealarchive.class.php');
class DealArchive_mysql extends DealArchive {}