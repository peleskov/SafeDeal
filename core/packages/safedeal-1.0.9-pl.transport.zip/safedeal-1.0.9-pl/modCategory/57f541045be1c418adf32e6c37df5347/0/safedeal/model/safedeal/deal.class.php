<?php
class Deal extends xPDOSimpleObject {}