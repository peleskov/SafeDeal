<?php
class DealNotice extends xPDOSimpleObject {}